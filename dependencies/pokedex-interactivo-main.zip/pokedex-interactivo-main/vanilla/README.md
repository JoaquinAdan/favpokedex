# Vanilla JavaScript

Proyecto con solo HTML + CSS y JavaScript. Sin complicaciones y listo para que lo cambies.