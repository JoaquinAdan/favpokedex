let date = document.getElementById('date');
date.innerText = `Fecha de hoy: ${new Date().toLocaleDateString()}`;